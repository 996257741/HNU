#include "BaseTrie.h"
#include <cctype>
#include<algorithm>
using namespace std;
// TrieNode ���캯��
TrieNode::TrieNode()
{
    for (int i = 0; i < ALPHABET_SIZE; ++i)
    {
        children[i] = NULL;
    }
    count = 0;
}

// Trie ���캯��
Trie::Trie()
{
    root = new TrieNode();
}

// Trie ��������
Trie::~Trie()
{
    freeMemory(root);
}

// ���ַ�ת��ΪСд
char Trie::toLower(char c)
{
    return tolower(static_cast<unsigned char>(c));
}

// �����ʲ��뵽 Trie ��
void Trie::insertWord(const string& word)
{
    TrieNode* node = root;
    for (char c : word)
    {
        c = toLower(c);
        if (node->children[c - 'a'] == NULL)
        {
            node->children[c - 'a'] = new TrieNode();
        }
        node = node->children[c - 'a'];
    }
    node->count++;
}

// �ݹ麯������ Trie ���ռ����ʼ������
void Trie::collectWords(TrieNode* node, string prefix, vector<pair<string, int> >& result)
{
    if (node->count > 0)
    {
        result.push_back({prefix, node->count});
    }
    for (int i = 0; i < ALPHABET_SIZE; ++i)
    {
        if (node->children[i] != NULL)
        {
            collectWords(node->children[i], prefix + static_cast<char>('a' + i), result);
        }
    }
}

// ��ȡ���������ֵ�˳������ĵ��ʼ������
vector<pair<string, int> > Trie::getSortedWords()
{
    vector<pair<string, int> > result;
    collectWords(root, "", result);
    sort(result.begin(), result.end(), [&](auto& a, auto& b) {
        return a.second > b.second || (a.second == b.second && a.first < b.first);
    });
    return result;
}

// �ͷ� Trie ռ�õ��ڴ�
void Trie::freeMemory(TrieNode* node)
{
    for (int i = 0; i < ALPHABET_SIZE; ++i)
    {
        if (node->children[i] != NULL)
        {
            freeMemory(node->children[i]);
        }
    }
    delete node;
}

