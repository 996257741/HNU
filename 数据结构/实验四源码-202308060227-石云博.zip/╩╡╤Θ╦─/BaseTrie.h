#ifndef TRIE_H
#define TRIE_H

#include <string>
#include <vector>
#include <algorithm>

const int ALPHABET_SIZE = 26;

// Trie Node
struct TrieNode
{
	TrieNode* children[ALPHABET_SIZE];
	int count;

	TrieNode();
};

class Trie
{
private:
	TrieNode* root;

public:
	Trie();
	~Trie();

	// Convert character to lowercase
	static char toLower(char c);

	// Insert word into Trie
	void insertWord(const std::string& word);

	// Recursive function to collect words and their counts from Trie
	void collectWords(TrieNode* node, std::string prefix, std::vector<std::pair<std::string, int> >& result);

	// Get words and their counts sorted by count and lexicographically
	std::vector<std::pair<std::string, int> > getSortedWords();

	// Free Trie memory
	void freeMemory(TrieNode* node);
};

#endif // TRIE_H

