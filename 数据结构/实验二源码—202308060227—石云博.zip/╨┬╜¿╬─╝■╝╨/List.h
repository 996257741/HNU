
#include"BaseList.h"

template <typename E> class List : public BaseList<E>{
private:
	int maxsize;
	int size;
	E* listArray;
public:
	List(int s)
	{
		maxsize=s;
		size=0;
		listArray=new E[maxsize];
	}
	~List() { delete [] listArray;}
    void push(const E& it) {
        if (size == maxsize) {
            maxsize *= 2;
            E* newArray = new E[maxsize];
            for (int i = 0; i < size; i++) {
                newArray[i] = listArray[i];
            }
            delete[] listArray;
            listArray = newArray;
        }
        listArray[size++] = it;
    }
	E back() {
        return listArray[size - 1];
    }
	bool empty() {
        return listArray == 0;
    }	
	void pop_front() {
        for (int i = 0; i < size - 1; i++) {
            listArray[i] = listArray[i + 1];
        }
        size--;
    }
	E front() {
        return listArray[0];
    }
	E length(){
		return size;
		}	
};

