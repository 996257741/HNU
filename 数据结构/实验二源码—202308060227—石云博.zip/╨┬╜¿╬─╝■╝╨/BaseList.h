#ifndef BASELIST_H
#define BASELIST_H

template <typename E>
class BaseList {
public:
    virtual ~BaseList() {}
    virtual void push(const E& it) = 0;
    virtual E back() = 0;
    virtual bool empty() = 0;
    virtual void pop_front() = 0;
    virtual E front() = 0;
    virtual E length() = 0;
};

#endif 
