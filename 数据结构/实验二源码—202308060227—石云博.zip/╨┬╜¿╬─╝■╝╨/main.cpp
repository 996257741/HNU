#include<iostream>
#include "BaseList.h"
#include"List.h"
using namespace std;

const int N = 100;
int res[N];
int main() {
    List<int>* l[N];
    for (int i=0;i<N;i++)
    {
    	l[i]=new List<int>(N);
	}
    int k = 1;
    int now = 1;
    int s;
    int o=0;
    while (cin >> res[o]) o++; 
	for (int i=o-1;i>=0;i--)
	{
		s=res[i];
        if (s == now) now++;
        else {
            int p = 0;
            int c = 0;
            bool st = false;
            for (int j = 2; j <= k; j++) {
                if (!l[j]->empty() && l[j]->front() == now) {
                	l[j]->pop_front();
                    now++;
                }
                if (!l[j]->empty() && s > l[j]->back()) {
                    st = true;
                    if (l[j]->back() > p) {
                        c = j;
                        p = l[j]->back();
                    }
                }
            }
            if (st == true) l[c]->push(s);
            else {
                k++;
                l[k]->push(s);
            }
        }
    }
    cout << k;
}

